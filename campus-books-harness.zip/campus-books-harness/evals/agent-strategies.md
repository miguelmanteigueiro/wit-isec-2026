# Avaliação proposta: loop principal e checkpoint de revisão

Estado: **não executada com modelos**. O defeito e os testes são reais; a comparação é um plano.

| Caso | Entrada | Oráculo humano/teste |
|---|---|---|
| B1 | pacote antes | RF05 viola autor omitido; o teste HTTP novo falha (502 em vez de 200) |
| C1 | pacote atual | a correção passa nos 24 testes; não assumir ausência de outros defeitos |

Comparar, com a mesma spec, ferramentas, permissões, orçamento e tarefa:
A. loop principal + checks e revisão humana;
B. o mesmo + revisão em contexto separado no mesmo modelo;
C. o mesmo + revisão em contexto separado noutro modelo.
Só testar subagentes especialistas adicionais se houver uma hipótese concreta de benefício.
Não enviar a B/C a solução/oráculo, conversa do autor ou review preparada. Avaliador humano
mantém o oráculo à parte. Repetir experiências; dois casos não sustentam generalização.

| Métrica | A | B | C |
|---|---|---|---|
| Defeito RF05 detetado e reproduzido | não medido | não medido | não medido |
| Findings confirmados / falsos positivos | não medido | não medido | não medido |
| Regressões depois da correção | não medido | não medido | não medido |
| Tempo total, custo/tokens e retrabalho humano | não medido | não medido | não medido |
| Perda de contexto / decisões em falta | não medido | não medido | não medido |

Registar modelo/versão, cliente, data, contexto efetivamente carregado, packet_id, permissões,
comandos, resultados e limitações por execução. Não confundir declarações no JSON com
telemetria autenticada. Não concluir que a estratégia com mais agentes é melhor por ter
mais findings, nem que zero findings demonstra correção.

Os pacotes didáticos e o prompt de foco têm pistas sobre o cenário RF05. Não são uma
avaliação cega. Para esse fim, construir variantes sem rótulos/pistas do defeito e manter
o oráculo fora de todos os inputs do revisor; conservar apenas decisões legítimas.
