# Review preparada da versão inicial

Escrita à mão para explicar o fluxo na palestra. Não deve entrar no contexto de um revisor:
é o oráculo para comparar com uma revisão real.

## Bloqueador: RF05 / CA03
`BookMapper.java`, linha 18 (tag `antes`): o ciclo sobre `doc.get("author_name")` assume
que o campo existe. Quando falta, a exceção é traduzida em 502. A spec exige 200 com
`authors: []`.

Reprodução: `./scripts/testar.sh antes`, teste `missingAuthorReturnsEmptyArray`,
esperado 200, observado 502.
Sugestão: distinguir ausência/null de tipo errado e acrescentar uma regressão HTTP.

## Sequência
- `antes`: 21 testes sem falhas. Nenhum cobre o autor omitido.
- `antes` com os testes novos: o teste HTTP do RF05 falha.
- `depois`: 24 testes sem falhas. A skill de integração ganha a regra dos campos omitidos/null.

## Limites antes de produção
Quota agregada entre réplicas, carga, isolamento do agente e política de rede não estão
resolvidos por estes testes. Não houve uma revisão de segurança completa.
