package pt.isec.campusbooks;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;

@Component
public class OpenLibraryClient {

    private final String base;
    private final Duration timeout;
    private final Duration minInterval;
    private final Clock clock;
    private Instant lastAttempt;
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(1))
            .followRedirects(HttpClient.Redirect.NEVER)
            .build();
    private final JsonMapper json = JsonMapper.builder().build();

    public OpenLibraryClient(
            @Value("${books.provider-base-url}") String base,
            @Value("${books.request-timeout-ms}") long timeout,
            @Value("${books.minimum-interval-ms}") long minInterval,
            Clock clock) {
        URI uri = URI.create(base);
        boolean production = uri.getScheme().equals("https")
                && uri.getHost().equals("openlibrary.org")
                && uri.getPort() == -1;
        boolean fixture = uri.getScheme().equals("http") && uri.getHost().equals("127.0.0.1");
        if ((!production && !fixture)
                || uri.getRawQuery() != null
                || uri.getUserInfo() != null
                || (uri.getPath() != null && !uri.getPath().isEmpty() && !uri.getPath().equals("/"))) {
            throw new IllegalArgumentException("Provider must be Open Library or the local fixture server");
        }
        this.base = base.replaceAll("/$", "");
        this.timeout = Duration.ofMillis(timeout);
        this.minInterval = Duration.ofMillis(minInterval);
        this.clock = clock;
    }

    private synchronized void reserve() {
        Instant now = clock.instant();
        if (lastAttempt != null && Duration.between(lastAttempt, now).compareTo(minInterval) < 0) {
            throw new ProviderFailure(503);
        }
        lastAttempt = now;
    }

    public SearchResult search(String query, int page) {
        reserve();
        String encoded = URLEncoder.encode(query, StandardCharsets.UTF_8);
        URI uri = URI.create(base + "/search.json?q=" + encoded + "&page=" + page
                + "&limit=3&fields=key,title,author_name,first_publish_year");
        HttpRequest request = HttpRequest.newBuilder(uri)
                .timeout(timeout)
                .header("User-Agent", "CampusBooksLecture/1.0 (educational prototype)")
                .header("Accept", "application/json")
                .GET()
                .build();
        try {
            HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 429) throw new ProviderFailure(503);
            if (response.statusCode() != 200) throw new ProviderFailure(502);

            JsonNode body = json.readTree(response.body());
            if (!body.path("docs").isArray()
                    || !body.path("numFound").isIntegralNumber()
                    || body.path("numFound").asLong() < 0
                    || body.path("docs").size() > 3) {
                throw new ProviderFailure(502);
            }

            var books = new ArrayList<Book>();
            for (JsonNode doc : body.path("docs")) books.add(BookMapper.from(doc));
            return new SearchResult(query, page, 3, body.path("numFound").asLong(), books);
        } catch (HttpTimeoutException e) {
            throw new ProviderFailure(504);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ProviderFailure(503);
        } catch (ProviderFailure e) {
            throw e;
        } catch (Exception e) {
            throw new ProviderFailure(502);
        }
    }
}
