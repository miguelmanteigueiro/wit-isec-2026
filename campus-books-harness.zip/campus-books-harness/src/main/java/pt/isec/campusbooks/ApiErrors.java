package pt.isec.campusbooks;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestControllerAdvice
public class ApiErrors {

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ProblemDetail> invalid() {
        return ResponseEntity.badRequest().body(ProblemDetail.forStatusAndDetail(
                HttpStatusCode.valueOf(400), "q must have 2–80 characters and page must be 1–10"));
    }

    @ExceptionHandler(ProviderFailure.class)
    public ResponseEntity<ProblemDetail> provider(ProviderFailure e) {
        var builder = ResponseEntity.status(e.status());
        if (e.status() == 503) builder.header("Retry-After", "1");
        return builder.body(ProblemDetail.forStatusAndDetail(
                HttpStatusCode.valueOf(e.status()), "External catalogue temporarily unavailable"));
    }
}
