# Instruções locais do backend

Ler `docs/integration.md` antes de alterar `OpenLibraryClient` ou `BookMapper`.
Manter o acesso a `java.net` no adapter. Não devolver o payload remoto diretamente.
Não alterar o comportamento de erros sem rever a spec e os testes HTTP.
