package pt.isec.campusbooks;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class BookSearchService {

    private final OpenLibraryClient client;
    private final Clock clock;
    private final Map<String, Cached> cache = new LinkedHashMap<>();

    private record Cached(Instant until, SearchResult result) {}

    public BookSearchService(OpenLibraryClient client, Clock clock) {
        this.client = client;
        this.clock = clock;
    }

    public synchronized SearchResult search(String raw, int page) {
        String query = raw == null ? "" : raw.strip().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
        int length = query.codePointCount(0, query.length());
        if (length < 2 || length > 80 || page < 1 || page > 10) {
            throw new IllegalArgumentException("Invalid search");
        }

        String key = query + "#" + page;
        Instant now = clock.instant();
        cache.entrySet().removeIf(e -> !now.isBefore(e.getValue().until()));
        Cached hit = cache.get(key);
        if (hit != null) return hit.result();

        SearchResult result = client.search(query, page);
        if (cache.size() >= 100) cache.remove(cache.keySet().iterator().next());
        cache.put(key, new Cached(clock.instant().plus(Duration.ofSeconds(60)), result));
        return result;
    }
}
