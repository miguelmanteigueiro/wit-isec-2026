package pt.isec.campusbooks;

import java.util.List;

public record SearchResult(String query, int page, int pageSize, long total, List<Book> books) {}
