package pt.isec.campusbooks;

import java.util.ArrayList;
import java.util.List;
import tools.jackson.databind.JsonNode;

public final class BookMapper {

    private BookMapper() {}

    public static Book from(JsonNode doc) {
        if (!doc.path("key").isString() || !doc.path("title").isString()
                || doc.path("title").asString().isBlank()) {
            throw new ProviderFailure(502);
        }

        List<String> authors = new ArrayList<>();
        JsonNode names = doc.get("author_name");
        if (names != null && !names.isNull() && !names.isArray()) {
            throw new ProviderFailure(502);
        }
        if (names != null && names.isArray()) {
            for (JsonNode author : names) {
                if (!author.isString()) throw new ProviderFailure(502);
                authors.add(author.asString());
            }
        }

        JsonNode year = doc.get("first_publish_year");
        if (year != null && !year.isNull() && !year.isIntegralNumber()) {
            throw new ProviderFailure(502);
        }

        return new Book(
                doc.path("key").asString(),
                doc.path("title").asString(),
                List.copyOf(authors),
                year == null || year.isNull() ? null : year.asInt());
    }
}
