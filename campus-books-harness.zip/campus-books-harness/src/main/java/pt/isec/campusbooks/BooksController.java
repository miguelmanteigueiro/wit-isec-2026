package pt.isec.campusbooks;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/books")
public class BooksController {

    private final BookSearchService service;

    public BooksController(BookSearchService service) {
        this.service = service;
    }

    @GetMapping
    public SearchResult search(@RequestParam String q, @RequestParam(defaultValue = "1") int page) {
        return service.search(q, page);
    }
}
