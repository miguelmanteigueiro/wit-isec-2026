package pt.isec.campusbooks;

import java.util.List;

public record Book(String workId, String title, List<String> authors, Integer firstPublicationYear) {}
