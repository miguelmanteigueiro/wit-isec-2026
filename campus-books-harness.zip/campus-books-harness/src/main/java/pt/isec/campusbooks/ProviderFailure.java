package pt.isec.campusbooks;

public final class ProviderFailure extends RuntimeException {

    private final int status;

    public ProviderFailure(int status) {
        super("External catalogue unavailable");
        this.status = status;
    }

    public int status() {
        return status;
    }
}
