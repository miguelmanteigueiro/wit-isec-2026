package pt.isec.campusbooks;

import org.junit.jupiter.api.*;
import java.time.Duration;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BookSearchServiceTest {

    OpenLibraryClient client;
    MutableClock clock;
    BookSearchService service;

    @BeforeEach
    void setup() {
        client = mock(OpenLibraryClient.class);
        clock = new MutableClock();
        service = new BookSearchService(client, clock);
    }

    @Test
    void normalizesAndCachesSuccessfulSearch() {
        var result = new SearchResult("software engineering", 1, 3, 0, List.of());
        when(client.search("software engineering", 1)).thenReturn(result);
        assertSame(result, service.search(" Software   Engineering ", 1));
        assertSame(result, service.search("software engineering", 1));
        verify(client, times(1)).search("software engineering", 1);
    }

    @Test
    void pageIsPartOfCacheKey() {
        when(client.search(anyString(), anyInt()))
                .thenAnswer(i -> new SearchResult(i.getArgument(0), i.getArgument(1), 3, 0, List.of()));
        service.search("java", 1);
        service.search("java", 2);
        verify(client, times(2)).search(eq("java"), anyInt());
    }

    @Test
    void expiresCacheAtSixtySeconds() {
        when(client.search("java", 1)).thenReturn(new SearchResult("java", 1, 3, 0, List.of()));
        service.search("java", 1);
        clock.advance(Duration.ofSeconds(60));
        service.search("java", 1);
        verify(client, times(2)).search("java", 1);
    }

    @Test
    void doesNotCacheProviderFailure() {
        when(client.search("java", 1)).thenThrow(new ProviderFailure(503));
        assertThrows(ProviderFailure.class, () -> service.search("java", 1));
        assertThrows(ProviderFailure.class, () -> service.search("java", 1));
        verify(client, times(2)).search("java", 1);
    }

    @Test
    void rejectsInvalidInputBeforeCallingProvider() {
        assertThrows(IllegalArgumentException.class, () -> service.search("x", 1));
        assertThrows(IllegalArgumentException.class, () -> service.search("java", 11));
        assertThrows(IllegalArgumentException.class, () -> service.search("java", 0));
        assertThrows(IllegalArgumentException.class, () -> service.search("a".repeat(81), 1));
        verifyNoInteractions(client);
    }

    @Test
    void boundsCacheSize() {
        when(client.search(anyString(), anyInt()))
                .thenAnswer(i -> new SearchResult(i.getArgument(0), i.getArgument(1), 3, 0, List.of()));
        for (int i = 0; i < 101; i++) service.search("query" + i, 1);
        service.search("query0", 1);
        verify(client, times(2)).search("query0", 1);
    }
}
