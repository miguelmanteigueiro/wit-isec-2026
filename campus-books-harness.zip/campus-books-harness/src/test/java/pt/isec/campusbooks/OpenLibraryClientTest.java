package pt.isec.campusbooks;

import org.junit.jupiter.api.*;
import java.time.Clock;
import static org.junit.jupiter.api.Assertions.*;

class OpenLibraryClientTest {

    FixtureServer stub;

    @BeforeEach
    void setup() throws Exception {
        stub = new FixtureServer();
    }

    @AfterEach
    void close() {
        stub.close();
    }

    OpenLibraryClient client() {
        return new OpenLibraryClient(stub.base(), 500, 0, Clock.systemUTC());
    }

    @Test
    void forwardsPageAndEncodesQuery() throws Exception {
        stub.fixture("complete");
        var result = client().search("a&b", 2);
        assertEquals(1, result.books().size());
        assertTrue(stub.lastUri.getRawQuery().contains("q=a%26b"));
        assertTrue(stub.lastUri.getRawQuery().contains("page=2"));
        assertTrue(stub.lastUri.getRawQuery().contains("limit=3"));
    }

    @Test
    void emptySearchIsSuccessful() {
        assertEquals(0, client().search("java", 1).books().size());
    }

    @Test
    void providerRateLimitBecomes503() {
        stub.status = 429;
        assertEquals(503, assertThrows(ProviderFailure.class, () -> client().search("java", 1)).status());
        assertEquals(1, stub.calls.get());
    }

    @Test
    void providerFailureBecomes502() {
        stub.status = 500;
        assertEquals(502, assertThrows(ProviderFailure.class, () -> client().search("java", 1)).status());
    }

    @Test
    void invalidJsonBecomes502() {
        stub.body = "not json";
        assertEquals(502, assertThrows(ProviderFailure.class, () -> client().search("java", 1)).status());
    }

    @Test
    void timeoutBecomes504() {
        stub.delayMillis = 300;
        var c = new OpenLibraryClient(stub.base(), 50, 0, Clock.systemUTC());
        assertEquals(504, assertThrows(ProviderFailure.class, () -> c.search("java", 1)).status());
    }

    @Test
    void limitsAttemptsWithoutWaiting() {
        var c = new OpenLibraryClient(stub.base(), 500, 1100, new MutableClock());
        c.search("java", 1);
        assertEquals(503, assertThrows(ProviderFailure.class, () -> c.search("other", 1)).status());
        assertEquals(1, stub.calls.get());
    }

    @Test
    void rejectsArbitraryProviderHost() {
        assertThrows(IllegalArgumentException.class,
                () -> new OpenLibraryClient("https://example.com", 500, 0, Clock.systemUTC()));
    }
}
