package pt.isec.campusbooks;

import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;

final class FixtureServer implements AutoCloseable {

    final HttpServer server;
    final ExecutorService executor = Executors.newCachedThreadPool();
    volatile int status = 200;
    volatile String body = "{\"numFound\":0,\"docs\":[]}";
    volatile long delayMillis;
    volatile URI lastUri;
    final AtomicInteger calls = new AtomicInteger();

    FixtureServer() throws Exception {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.setExecutor(executor);
        server.createContext("/search.json", exchange -> {
            calls.incrementAndGet();
            lastUri = exchange.getRequestURI();
            try {
                if (delayMillis > 0) Thread.sleep(delayMillis);
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                exchange.sendResponseHeaders(status, bytes.length);
                exchange.getResponseBody().write(bytes);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                exchange.close();
            }
        });
        server.start();
    }

    String base() {
        return "http://127.0.0.1:" + server.getAddress().getPort();
    }

    void fixture(String name) throws Exception {
        try (var in = getClass().getResourceAsStream("/fixtures/" + name + ".json")) {
            body = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    public void close() {
        server.stop(0);
        executor.shutdownNow();
    }
}
