package pt.isec.campusbooks;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import java.net.URI;
import java.net.http.*;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {"books.minimum-interval-ms=0", "books.request-timeout-ms=500"})
class BooksHttpTest {

    static final FixtureServer stub;

    static {
        try {
            stub = new FixtureServer();
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    @DynamicPropertySource
    static void configure(DynamicPropertyRegistry r) {
        r.add("books.provider-base-url", stub::base);
    }

    @Autowired
    Environment environment;

    @BeforeEach
    void setup() throws Exception {
        stub.status = 200;
        stub.delayMillis = 0;
        stub.fixture("complete");
    }

    @AfterAll
    static void close() {
        stub.close();
    }

    HttpResponse<String> request(String query) throws Exception {
        String port = environment.getProperty("local.server.port");
        URI uri = URI.create("http://127.0.0.1:" + port + "/api/books?q=" + query);
        return HttpClient.newHttpClient().send(
                HttpRequest.newBuilder(uri).GET().build(), HttpResponse.BodyHandlers.ofString());
    }

    @Test
    void completeBookReturns200() throws Exception {
        var r = request(UUID.randomUUID().toString());
        assertEquals(200, r.statusCode());
        assertTrue(r.body().contains("Demo Author"));
    }

    @Test
    void invalidQueryReturns400WithoutProviderCall() throws Exception {
        int before = stub.calls.get();
        var r = request("x");
        assertEquals(400, r.statusCode());
        assertEquals(before, stub.calls.get());
    }

    @Test
    void providerOutageDoesNotLookLikeEmptyResults() throws Exception {
        stub.status = 500;
        var r = request(UUID.randomUUID().toString());
        assertEquals(502, r.statusCode());
        assertFalse(r.body().contains("\"books\""));
        assertTrue(r.headers().firstValue("content-type").orElse("").contains("application/problem+json"));
    }

    @Test
    void missingAuthorReturnsEmptyArray() throws Exception {
        stub.fixture("missing-author");
        var response = request(UUID.randomUUID().toString());
        assertEquals(200, response.statusCode());
        assertTrue(response.body().contains("\"authors\":[]"));
    }
}
