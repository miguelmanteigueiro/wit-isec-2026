package pt.isec.campusbooks;

import java.time.*;

final class MutableClock extends Clock {

    private Instant now = Instant.parse("2026-10-30T12:00:00Z");

    void advance(Duration d) {
        now = now.plus(d);
    }

    public ZoneId getZone() {
        return ZoneOffset.UTC;
    }

    public Clock withZone(ZoneId z) {
        return this;
    }

    public Instant instant() {
        return now;
    }
}
