package pt.isec.campusbooks;

import org.junit.jupiter.api.Test;
import tools.jackson.databind.json.JsonMapper;
import static org.junit.jupiter.api.Assertions.*;

class BookMapperTest {

    private final JsonMapper json = JsonMapper.builder().build();

    @Test
    void mapsCompleteDocument() {
        var book = BookMapper.from(json.readTree(
                "{\"key\":\"/works/1\",\"title\":\"Title\",\"author_name\":[\"A\"],\"first_publish_year\":2020}"));
        assertEquals("A", book.authors().getFirst());
        assertEquals(2020, book.firstPublicationYear());
    }

    @Test
    void preservesMissingYearAsNull() {
        var book = BookMapper.from(json.readTree(
                "{\"key\":\"/works/1\",\"title\":\"Title\",\"author_name\":[]}"));
        assertNull(book.firstPublicationYear());
    }

    @Test
    void ignoresUnknownFields() {
        var book = BookMapper.from(json.readTree(
                "{\"key\":\"/works/1\",\"title\":\"Title\",\"author_name\":[],\"other\":\"untrusted data\"}"));
        assertEquals("Title", book.title());
    }

    @Test
    void rejectsMissingTitle() {
        assertEquals(502, assertThrows(ProviderFailure.class,
                () -> BookMapper.from(json.readTree("{\"key\":\"/works/1\"}"))).status());
    }

    @Test
    void normalizesNullAuthors() {
        var book = BookMapper.from(json.readTree(
                "{\"key\":\"/works/1\",\"title\":\"Title\",\"author_name\":null}"));
        assertTrue(book.authors().isEmpty());
    }

    @Test
    void rejectsWrongAuthorType() {
        assertThrows(ProviderFailure.class, () -> BookMapper.from(json.readTree(
                "{\"key\":\"/works/1\",\"title\":\"Title\",\"author_name\":\"wrong\"}")));
    }
}
