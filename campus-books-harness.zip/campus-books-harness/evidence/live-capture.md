# Proveniência da captura real

Data de captura: 30/10/2026, UTC. Cabeçalho HTTP Date em openlibrary.headers.
URL: https://openlibrary.org/search.json?q=software%20engineering&limit=3&fields=key,title,author_name,first_publish_year
Resposta pública, sem chave e sem informação pessoal enviada. Resultados podem mudar.
Dados: Open Library / Internet Archive. Não representam stock ou disponibilidade de empréstimo.
As fixtures de teste são sintéticas e separadas desta captura.
