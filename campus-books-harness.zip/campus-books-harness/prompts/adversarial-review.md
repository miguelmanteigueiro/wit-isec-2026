# Revisão adversarial: procurar contraexemplos, não confirmar o autor

Abrir num contexto separado, com os acessos mínimos. Ler docs/review-protocol.md e o
review-input.md do pacote; usar o respetivo report-template.json. Não ler a conversa,
plano ou review preparada do autor. Ler spec, decisões aprovadas, diff, código e testes
relevantes e resultados dos checks. Pedir contexto se uma decisão necessária estiver em falta.

Objetivo: encontrar um cenário concreto que viole um requisito ou uma restrição aprovada.
Inspecionar sobretudo RF05/CA03, erros HTTP, cache/paginação, quota e fronteira de rede.
Não pressupor que há um defeito. Zero findings é válido; não inventar uma quota.

Para cada finding registar ficheiro/linha, ID, impacto, reprodução ou teste proposto e
estado da evidência: hypothesis, reproduced ou not_reproduced. Um teste proposto não é
um teste executado. Priorizar por impacto; não bloquear por preferências sem fundamento.

Não editar a implementação. Reproduzir apenas numa cópia descartável autorizada, sem API
pública nem alargamento de permissões. Distinguir logs históricos da versão atual.
Declarar limitações, contexto realmente usado e modelos reais quando conhecidos.
Um modelo diferente pode diversificar a perspetiva, mas os erros podem ser correlacionados.

Entregar JSON vinculado ao packet_id. review_status=completed só depois de realizar a revisão.
Não fabricar identidade do modelo, isolamento ou execução. Não aprovar merge autonomamente.
Se não houver acordo, apresentar o requisito, contraexemplo e evidência à pessoa responsável.
