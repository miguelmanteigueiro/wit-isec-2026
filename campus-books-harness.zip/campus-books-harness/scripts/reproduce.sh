#!/bin/sh
# Reproduz a sequência completa a partir das versões guardadas no Git:
#   antes:                  suite da versão antes, verde
#   antes + testes novos:   o teste do RF05 falha
#   depois:                 suite completa, verde
# Cada passo corre numa cópia temporária; o checkout atual não é alterado.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT="$ROOT/evidence/reproduced"
WORK=$(mktemp -d)

cleanup() {
    git -C "$ROOT" worktree remove --force "$WORK" 2>/dev/null || rm -rf "$WORK"
}
trap cleanup EXIT HUP INT TERM

mkdir -p "$OUT"
git -C "$ROOT" worktree add --quiet --detach "$WORK" antes
maven() {
    (cd "$WORK" && ./mvnw -B -ntp verify) > "$OUT/$1" 2>&1
}

maven 1-antes.log
grep -q 'Failures: 0, Errors: 0' "$OUT/1-antes.log"

git -C "$WORK" checkout --quiet depois -- src/test
if maven 2-antes-com-teste-novo.log; then
    echo 'ERRO: o teste do RF05 devia falhar no código antes da correção'
    exit 1
fi
grep -q 'missingAuthorReturnsEmptyArray' "$OUT/2-antes-com-teste-novo.log"

git -C "$WORK" checkout --quiet --force depois
maven 3-depois.log
grep -q 'Tests run: 24, Failures: 0, Errors: 0' "$OUT/3-depois.log"

echo 'Reproduzido: antes verde, teste novo falha no código antigo, depois 24 testes verdes.'
echo "Logs em $OUT"
