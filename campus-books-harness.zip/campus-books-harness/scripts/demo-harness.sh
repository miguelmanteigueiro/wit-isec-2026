#!/bin/sh
# Demo da palestra: uma sessão de um engenheiro com o agente, seguindo o percurso do harness.
# Os pedidos e as respostas são um guião. Os ficheiros, a revisão do agente, os testes e o
# diff são reais e lidos do Git a cada execução. Enter para avançar.
#
#   ./scripts/demo-harness.sh            corre os testes ao vivo (em segundo plano)
#   ./scripts/demo-harness.sh --gravado  usa as saídas guardadas em evidence/reserva/, sem Maven
#   DEMO_RAPIDO=1 ./scripts/demo-harness.sh   sem animação (para ensaiar depressa)
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
OUT="$ROOT/evidence/demo"
mkdir -p "$OUT"
RAPIDO=${DEMO_RAPIDO:-}

B=$(printf '\033[1m'); D=$(printf '\033[2m'); R=$(printf '\033[0m')
VERDE=$(printf '\033[32m'); VERMELHO=$(printf '\033[31m'); INV=$(printf '\033[7m')
AZUL=$(printf '\033[36m'); LARANJA=$(printf '\033[38;5;209m')

PIDS=
parar() { for p in $PIDS; do kill "$p" 2>/dev/null || true; done; }
trap parar EXIT HUP INT TERM

# Os testes demoram; arrancam já, enquanto se explica o contexto.
if [ "${1:-}" = --gravado ]; then
    for v in antes depois; do
        if [ -f "$ROOT/evidence/palestra/$v.txt" ]; then
            cp "$ROOT/evidence/palestra/$v.txt" "$OUT/passo-$v.txt"
        else
            cp "$ROOT/evidence/reserva/$v.txt" "$OUT/passo-$v.txt"
        fi
    done
    PID_ANTES=; PID_DEPOIS=
else
    ./scripts/testar.sh antes > "$OUT/passo-antes.txt" 2>&1 & PID_ANTES=$!
    sleep 1
    ./scripts/testar.sh depois > "$OUT/passo-depois.txt" 2>&1 & PID_DEPOIS=$!
    PIDS="$PID_ANTES $PID_DEPOIS"
fi

# --- Apresentação -------------------------------------------------------------

pausa() { [ -n "$RAPIDO" ] || sleep "${1:-0.5}"; }

percurso() {
    linha=''
    for etapa in Contexto Revisão Teste Correção Decisão; do
        if [ "$etapa" = "$1" ]; then linha="$linha ${INV}${B} $etapa ${R}"
        else linha="$linha ${D} $etapa ${R}"; fi
    done
    clear 2>/dev/null || true
    printf '\n %s\n' "$linha"
    printf ' %sGuião: pedidos e respostas. Reais: ficheiros, revisão, testes e diff.%s\n\n' "$D" "$R"
    printf '%s%s%s\n\n' "$B" "$2" "$R"
}

nota() { printf '  %s%s%s\n\n' "$D" "$1" "$R"; }

# O pedido do engenheiro, escrito como se estivesse a ser digitado.
engenheiro() {
    python3 - "$1" "$RAPIDO" "$AZUL$B" "$R" <<'PY'
import sys, textwrap, time
texto, rapido, cor, fim = sys.argv[1:5]
linhas = textwrap.wrap(texto, 72)
sys.stdout.write(f"  {cor}❯{fim} {cor}")
for i, linha in enumerate(linhas):
    if i:
        sys.stdout.write("\n    ")
    for c in linha:
        sys.stdout.write(c); sys.stdout.flush()
        if not rapido:
            time.sleep(0.012)
sys.stdout.write(f"{fim}\n\n"); sys.stdout.flush()
PY
    pausa 0.8
}

# Uma ação do agente no harness: ferramenta(argumento), com a saída indentada.
acao() {
    printf '  %s●%s %s%s%s(%s)\n' "$LARANJA" "$R" "$B" "$1" "$R" "$2"
    pausa 0.3
}
saida() {
    awk 'NR==1 { printf "    ⎿  %s\n", $0; next } { printf "       %s\n", $0 }'
    printf '\n'
    pausa 0.5
}

# A resposta do agente em texto.
agente() {
    printf '  %s●%s %s\n' "$LARANJA" "$R" "$1"
    shift
    for l in "$@"; do printf '    %s\n' "$l"; done
    printf '\n'
}

avancar() { printf '%s[Enter]%s ' "$D" "$R"; { read _ < /dev/tty; } 2>/dev/null || true; }

esperar() {
    pid=$1
    [ -n "$pid" ] || return 0
    printf '    %sA correr o teste' "$D"
    while kill -0 "$pid" 2>/dev/null; do printf '.'; sleep 1; done
    printf '%s\r\033[K' "$R"
}

resultado() {
    grep -E 'Tests run:|expected:|BUILD' "$1" \
        | sed -e 's/^\[[A-Z]*\] *//' -e 's/^org\.opentest4j\.//' \
              -e "s/BUILD FAILURE/${VERMELHO}${B}BUILD FAILURE${R}/" \
              -e "s/BUILD SUCCESS/${VERDE}${B}BUILD SUCCESS${R}/" \
              -e "s/\(expected: <200> but was: <502>\)/${VERMELHO}\1${R}/"
}

diff_limpo() {
    git --no-pager diff --color=always -U0 antes depois -- "$@" \
        | grep -v -E '^(.\[1m)?(diff|index|---|\+\+\+)' \
        | grep -v -E '^(.\[36m)?@@' \
        | grep -v -E '^(.\[32m)?\+(.\[m)?$'
}

# 1 · Contexto -------------------------------------------------------------------
percurso Contexto '1. O engenheiro pede a implementação. O harness dá o contexto.'
engenheiro 'Implementa a pesquisa de livros descrita em specs/book-search.md. Lê o AGENTS.md, usa a skill integrate-public-api e diz-me o plano antes de editar.'
acao Read AGENTS.md
git show antes:AGENTS.md | grep -E 'testes não chamam|nunca se transforma|Uma pessoa aceita' \
    | sed 's/^- //' | fold -s -w 74 | saida
acao Read specs/book-search.md
git show antes:specs/book-search.md | grep -A1 '^- \*\*RF05\*\*' | sed 's/^- //; s/^  //; s/\*\*//g; s/`//g' \
    | tr '\n' ' ' | fold -s -w 74 | saida
acao Skill integrate-public-api
git show antes:.agents/skills/integrate-public-api/SKILL.md | grep -E '^[3-6]\.' | saida
agente 'Plano: o BookMapper traduz a resposta da Open Library para o nosso contrato,' \
       'com fixtures sintéticas e testes offline. Avanço?'
nota '[ o engenheiro aprova o plano; o agente implementa e corre ./scripts/verify.sh: 21 testes verdes ]'
avancar

# 2 · Revisão --------------------------------------------------------------------
percurso Revisão '2. Outro agente, noutro contexto, procura um contraexemplo'
nota 'Sessão nova · só o pacote da versão antes · sem a conversa nem o plano do autor'
engenheiro 'Revê este pacote seguindo adversarial-review.md. Não edites ficheiros em source/. Guarda o relatório em report.json.'
acao Read source/specs/book-search.md
printf '    ⎿  RF05, CA03: autor omitido/null produz 200 com authors: []\n\n'
pausa 0.5
acao Read source/.../BookMapper.java
git show antes:src/main/java/pt/isec/campusbooks/BookMapper.java | awk -v v="$VERMELHO" -v r="$R" \
    'NR>=17 && NR<=21 { if (NR==18) printf "%s%3d  %s%s\n", v, NR, $0, r; else printf "%3d  %s\n", NR, $0 }' | saida
REVISAO=$(ls evidence/revisao-agente-*.json 2>/dev/null | tail -1 || true)
if [ -n "$REVISAO" ]; then cp "$REVISAO" "$OUT/revisao.json"
elif ! git show main:evidence/revisao-agente-2026-11-16.json > "$OUT/revisao.json" 2>/dev/null; then
    cp reviews/adversarial-review.prepared.json "$OUT/revisao.json"
fi
acao Write report.json
python3 - "$OUT/revisao.json" <<'PY' | saida
import json, sys
f = json.load(open(sys.argv[1]))["findings"][0]
ficheiro = f["file"].split("/")[-1]
requisito = f["requirement"].split(":")[0]
print(f"{f['id']} · {ficheiro}:{f['line']} · {requisito} · {f['evidence_status']}")
PY
python3 - "$OUT/revisao.json" "$LARANJA" "$D" "$R" <<'PY'
import json, sys, textwrap
caminho, laranja, dim, fim = sys.argv[1:5]
r = json.load(open(caminho))
f = r["findings"][0]
partes = f["impact"].split(". ")
texto = (partes[1] if len(partes) > 1 and len(partes[0]) < 15 else partes[0]).strip().rstrip(".") + "."
linhas = textwrap.wrap(texto, 70)
print(f"  {laranja}●{fim} " + linhas[0])
for l in linhas[1:]:
    print("    " + l)
if f["evidence_status"] == "hypothesis":
    print("    Não corri testes: é uma hipótese, ainda por reproduzir.")
print()
modelo = (r.get("models") or {}).get("reviewer")
if modelo:
    print(f"  {dim}Relatório real de um agente ({modelo}), guardado em evidence/.{fim}")
else:
    print(f"  {dim}Finding preparado por nós (sem relatório real no repositório).{fim}")
PY
printf '\n'
avancar

# 3 · Teste ----------------------------------------------------------------------
percurso Teste '3. Antes de corrigir, um teste tem de reproduzir o problema'
nota 'De volta à sessão principal'
engenheiro 'Há um finding sobre o RF05: autor omitido deve dar authors vazio. Antes de corrigir, escreve um teste HTTP para esse caso e confirma que falha.'
acao Edit src/test/.../BooksHttpTest.java
diff_limpo src/test/java/pt/isec/campusbooks/BooksHttpTest.java | saida
acao Bash './scripts/testar.sh antes'
esperar "${PID_ANTES:-}"
resultado "$OUT/passo-antes.txt" | saida
if grep -q 'but was: <502>' "$OUT/passo-antes.txt"; then
    agente 'Esperava 200 e recebi 502. O finding confirma-se: o teste falha no código atual.'
else
    agente "O teste não falhou como esperado. Ver $OUT/testar-antes.log antes de continuar."
fi
avancar

# 4 · Correção -------------------------------------------------------------------
percurso Correção '4. A correção muda o código, os testes e a skill'
engenheiro 'Corrige no BookMapper. Se a skill devia ter evitado isto, acrescenta a regra.'
acao Edit src/main/.../BookMapper.java
diff_limpo src/main | saida
acao Edit .agents/skills/integrate-public-api/SKILL.md
diff_limpo .agents | saida
N=$(git diff --name-only antes depois | wc -l | tr -d ' ')
agente 'Omitido ou null dá lista vazia; um tipo errado continua a ser 502.' \
       "Mudaram $N ficheiros: o mapper, dois ficheiros de testes e a skill."
avancar

# 5 · Decisão --------------------------------------------------------------------
percurso Decisão '5. O mesmo teste no código corrigido. Quem aceita é uma pessoa.'
engenheiro 'Corre o mesmo teste no código corrigido.'
acao Bash './scripts/testar.sh depois'
esperar "${PID_DEPOIS:-}"
resultado "$OUT/passo-depois.txt" | saida
if grep -q 'BUILD SUCCESS' "$OUT/passo-depois.txt"; then
    agente 'O teste passa. Não fiz commit: aceitar a alteração é decisão tua.'
else
    agente "O teste não passou. Não aceitar. Ver $OUT/testar-depois.log."
fi
printf '%sAceitar a alteração? [s/N]%s ' "$B" "$R"
resposta=
{ read resposta < /dev/tty; } 2>/dev/null || true
case "$resposta" in
    s|S) printf '\n  %sAceite por uma pessoa, com a evidência acima.%s\n\n' "$VERDE" "$R" ;;
    *)   printf '\n  Não aceite. Fica registado o que falta verificar.\n\n' ;;
esac
