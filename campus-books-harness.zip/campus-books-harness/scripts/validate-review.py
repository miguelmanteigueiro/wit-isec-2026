#!/usr/bin/env python3
"""Valida a estrutura de um relatório de revisão e o vínculo ao pacote."""
import argparse
import json

from review_support import validate

parser = argparse.ArgumentParser()
parser.add_argument("--packet", required=True)
parser.add_argument("--report", required=True)
args = parser.parse_args()

try:
    with open(args.report) as handle:
        errors = validate(args.packet, json.load(handle))
except (ValueError, OSError, KeyError, TypeError) as error:
    parser.exit(2, f"Invalid packet/report: {error}\n")

if errors:
    parser.exit(2, "\n".join(errors) + "\n")

print("REPORT STRUCTURE VALID. Human acceptance still required. "
      "Model execution and findings are not authenticated.")
