#!/usr/bin/env python3
"""Servidor local de replay e de falhas. Nunca chama o fornecedor público."""
import argparse
import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCENARIOS = ["replay", "missing-author", "rate-limit", "timeout", "bad-json"]

parser = argparse.ArgumentParser()
parser.add_argument("--scenario", default="replay", choices=SCENARIOS)
parser.add_argument("--port", type=int, default=18081)
args = parser.parse_args()


def search_response(scenario: str) -> tuple[int, bytes]:
    if scenario == "timeout":
        time.sleep(4)
    if scenario == "rate-limit":
        return 429, b'{"error":"synthetic rate limit"}'
    if scenario == "bad-json":
        return 200, b"not json"
    if scenario == "missing-author":
        return 200, (ROOT / "src/test/resources/fixtures/missing-author.json").read_bytes()
    return 200, (ROOT / "evidence/openlibrary-live.json").read_bytes()


class Handler(BaseHTTPRequestHandler):
    calls = 0

    def log_message(self, *_):
        pass

    def do_GET(self):
        if self.path == "/__stats":
            status = 200
            payload = json.dumps({"upstreamRequests": Handler.calls, "mode": args.scenario}).encode()
        elif self.path.startswith("/search.json?"):
            Handler.calls += 1
            status, payload = search_response(args.scenario)
        else:
            status, payload = 404, b"{}"

        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass


ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
