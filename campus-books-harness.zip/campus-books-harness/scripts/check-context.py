#!/usr/bin/env python3
"""Verificação determinística do contexto e da arquitetura. Não é uma sandbox."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "AGENTS.md",
    "specs/book-search.md",
    "docs/integration.md",
    "docs/testing.md",
    "docs/architecture.md",
    "docs/traceability.md",
    "docs/openapi.json",
    "docs/review-protocol.md",
    "prompts/adversarial-review.md",
    "scripts/prepare-review.py",
    "scripts/validate-review.py",
    "evals/agent-strategies.md",
    ".agents/skills/integrate-public-api/SKILL.md",
    ".agents/skills/review-change/SKILL.md",
]

SPEC_TOPICS = [
    "Assumptions",
    "Requisitos funcionais",
    "Requisitos não funcionais",
    "Requisitos de segurança",
    "Critérios de aceitação",
    "Fora de âmbito",
]


def check() -> list[str]:
    errors = []

    for name in REQUIRED_FILES:
        if not (ROOT / name).is_file():
            errors.append(f"Missing {name}")

    agents = ROOT / "AGENTS.md"
    if agents.is_file() and len(agents.read_text().splitlines()) > 80:
        errors.append("AGENTS.md exceeds 80 lines")

    spec = ROOT / "specs/book-search.md"
    if spec.is_file():
        text = spec.read_text()
        for topic in SPEC_TOPICS:
            if topic not in text:
                errors.append(f"Missing spec topic: {topic}")
        ids = re.findall(r"^- \*\*((?:AS|RF|RNF|RS|CA)\d+)\*\*", text, re.M)
        if len(ids) != len(set(ids)):
            errors.append("Duplicate requirement ID")

    for source in (ROOT / "src/main/java").rglob("*.java"):
        if source.name != "OpenLibraryClient.java" and re.search(r"import\s+java\.net\.", source.read_text()):
            errors.append(f"Network import outside adapter: {source.name}")

    openapi = ROOT / "docs/openapi.json"
    if openapi.is_file():
        try:
            json.loads(openapi.read_text())
        except ValueError:
            errors.append("Invalid OpenAPI JSON")

    return errors


if __name__ == "__main__":
    problems = check()
    if problems:
        print("\n".join(problems), file=sys.stderr)
        sys.exit(2)
    print("CONTEXT CHECK PASSED: topics, required files, IDs, OpenAPI JSON syntax and network import boundary")
