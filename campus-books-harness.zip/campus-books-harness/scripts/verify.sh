#!/bin/sh
# Perfil completo de verificação: contexto, helpers Python e Maven verify.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

python3 scripts/check-context.py
python3 -m unittest discover -s scripts/tests -v
./mvnw -B -ntp verify
