"""Prepara pacotes de revisão isolados e valida a estrutura dos relatórios.

Nunca chama um modelo. A versão antes da correção vem da tag Git `antes`.
"""
import hashlib
import io
import json
import re
import shutil
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

BASELINE_TAG = "antes"

COPY = [
    "mvnw", ".mvn", "pom.xml",
    "src/main/java", "src/main/resources", "src/test/java", "src/test/resources",
    "specs/book-search.md",
    "docs/integration.md", "docs/architecture.md", "docs/testing.md",
    "docs/review-protocol.md", "docs/openapi.json",
]

EVIDENCE_LOG = {"antes": None, "atual": "verify-2026-11-12.log"}

REVIEW_INPUT = """# Revisão crítica com contexto separado

Ler source/specs/book-search.md, change.diff e os ficheiros relevantes de source/.
Decisões aprovadas: contrato próprio, campos opcionais, cache e sem retry automático.
Inspecionar os testes e a evidência datada em evidence/. Não assumir que logs antigos
comprovam o snapshot atual. Não usar o plano, a review preparada ou a narrativa do autor.
Pedir contexto adicional se uma decisão necessária estiver em falta.

Procurar contraexemplos à spec, sem quota de findings. Para cada observação:
localização, requisito, impacto, reprodução/teste proposto e estado da evidência.
Não editar a implementação. Testes adicionais só numa cópia descartável autorizada.
Não contactar a API pública nem alterar permissões para desbloquear a revisão.
Usar report-template.json e registar modelos/contexto reais, sem inventar dados.
Formato de cada finding: file (caminho relativo a source/, por exemplo
src/main/java/pt/isec/campusbooks/BookMapper.java), line, requirement (IDs da spec,
por exemplo RF05), impact, reproduction e evidence_status (hypothesis, reproduced
ou not_reproduced). context_isolated: true só se o contexto foi de facto separado.
A decisão de aceitar é humana. O script não chama qualquer modelo.
"""


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(source: Path) -> dict:
    return {
        str(p.relative_to(source)).replace("\\", "/"): digest(p)
        for p in sorted(source.rglob("*"))
        if p.is_file()
    }


def packet_id(files: dict) -> str:
    return hashlib.sha256(json.dumps(files, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def git(root: Path, *args: str) -> bytes:
    return subprocess.run(["git", "-C", str(root), *args], check=True, capture_output=True).stdout


def check_output_path(root: Path, output: Path) -> None:
    if output.exists():
        raise ValueError("Choose a new output directory; snapshots are not overwritten")
    if output == root:
        raise ValueError("Output must not overwrite project inputs")
    if root in output.parents and output.relative_to(root).parts[0] != ".review":
        raise ValueError("Inside the project, use .review/<new-name>")


def copy_current(root: Path, source: Path) -> None:
    for name in COPY:
        src, dst = root / name, source / name
        if src.is_dir():
            shutil.copytree(src, dst)
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)


def copy_before(root: Path, source: Path) -> None:
    archive = git(root, "archive", "--format=tar", BASELINE_TAG, "--", *COPY)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            target = (source / member.name).resolve()
            if not target.is_relative_to(source.resolve()):
                raise ValueError(f"Unexpected path in archive: {member.name}")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(tar.extractfile(member).read())
            if member.mode & 0o111:
                target.chmod(0o755)


def prepare(root, output, revision="atual"):
    root, output = Path(root).resolve(), Path(output).resolve()
    if revision not in ("atual", "antes"):
        raise ValueError("Unknown revision")
    check_output_path(root, output)

    output.mkdir(parents=True)
    source = output / "source"
    source.mkdir()
    if revision == "antes":
        copy_before(root, source)
        diff = "Versão antes da correção (tag antes).\n"
    else:
        copy_current(root, source)
        diff = git(root, "diff", BASELINE_TAG, "--", "src/main/java", "src/test/java").decode()
    (output / "change.diff").write_text(diff)

    # Evidência datada à parte; sem histórico, plano do autor ou review preparada.
    evidence = output / "evidence"
    evidence.mkdir()
    log = root / "evidence" / (EVIDENCE_LOG[revision] or "")
    if EVIDENCE_LOG[revision] and log.is_file():
        shutil.copy2(log, evidence / log.name)

    files = inventory(source)
    assets = {"change.diff": digest(output / "change.diff")}
    assets.update({str(p.relative_to(output)): digest(p) for p in sorted(evidence.glob("*")) if p.is_file()})
    identity = packet_id({"source/" + k: v for k, v in files.items()} | assets)

    manifest = {
        "schema_version": 1,
        "packet_id": identity,
        "revision": revision,
        "revision_kind": "git_tag_antes" if revision == "antes" else "current_local_snapshot",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source_files": files,
        "assets": assets,
        "excluded": ["plans/", "reviews/", "prompts/implement-change.md", "author conversation history"],
        "limitations": [
            "A content fingerprint is not a signature or sandbox.",
            "Model identity and context isolation are not authenticated by these helpers.",
        ],
    }
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2))

    template = {
        "packet_id": identity,
        "review_status": "not_run",
        "mode": "fresh_context",
        "models": {"implementer": None, "reviewer": None},
        "context_isolated": None,
        "findings": [],
        "limitations": ["Review not performed; do not infer approval."],
    }
    (output / "report-template.json").write_text(json.dumps(template, ensure_ascii=False, indent=2))
    (output / "review-input.md").write_text(REVIEW_INPUT)
    return manifest


def validate_finding(i: int, finding, source: Path, ids: set) -> list:
    if not isinstance(finding, dict):
        return [f"Finding {i}: must be an object"]
    errors = []
    location = str(finding.get("file", ""))
    if location.startswith("source/"):
        location = location[len("source/"):]
    path = (source / location).resolve()
    if not location or not path.is_relative_to(source.resolve()) or not path.is_file():
        errors.append(f"Finding {i}: file outside snapshot or missing")
    else:
        line = finding.get("line")
        count = len(path.read_text().splitlines())
        if not isinstance(line, int) or isinstance(line, bool) or not 1 <= line <= count:
            errors.append(f"Finding {i}: invalid line")
    cited = re.findall(r"\b(?:AS|RF|RNF|RS|CA)\d+\b", str(finding.get("requirement", "")))
    if not cited or any(c not in ids for c in cited):
        errors.append(f"Finding {i}: requirement must cite spec IDs (e.g. RF05)")
    for key in ("impact", "reproduction"):
        if not isinstance(finding.get(key), str) or not finding[key].strip():
            errors.append(f"Finding {i}: missing {key}")
    if finding.get("evidence_status") not in ("hypothesis", "reproduced", "not_reproduced"):
        errors.append(f"Finding {i}: distinguish hypothesis from evidence")
    return errors


def validate(packet, report):
    packet = Path(packet)
    manifest = json.loads((packet / "manifest.json").read_text())
    source = packet / "source"
    errors = []

    actual = inventory(source)
    assets = {name: digest(packet / name) for name in manifest["assets"] if (packet / name).is_file()}
    if actual != manifest["source_files"] or assets != manifest["assets"]:
        errors.append("Snapshot/evidence changed: create a new packet and review")
    if packet_id({"source/" + k: v for k, v in actual.items()} | assets) != manifest["packet_id"]:
        errors.append("Packet fingerprint mismatch")
    if report.get("packet_id") != manifest["packet_id"]:
        errors.append("Report belongs to a different packet")
    if report.get("review_status") != "completed":
        errors.append("Review is not completed; prepared/not_run is not approval")
    if report.get("context_isolated") is not True:
        errors.append("Context isolation declaration is missing")

    mode = report.get("mode")
    models = report.get("models", {})
    if mode not in ("fresh_context", "cross_model"):
        errors.append("Unknown review mode")
    if mode == "cross_model" and (
        not models.get("implementer")
        or not models.get("reviewer")
        or models["implementer"] == models["reviewer"]
    ):
        errors.append("Cross-model mode needs distinct declared model IDs")

    ids = set(re.findall(r"\*\*((?:AS|RF|RNF|RS|CA)\d+)\*\*", (source / "specs/book-search.md").read_text()))
    findings = report.get("findings")
    if not isinstance(findings, list):
        errors.append("findings must be a list")
        findings = []
    if not isinstance(report.get("limitations"), list):
        errors.append("limitations must be a list")
    for i, finding in enumerate(findings):
        errors.extend(validate_finding(i, finding, source, ids))
    return errors
