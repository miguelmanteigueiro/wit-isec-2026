#!/bin/sh
# Arranca a aplicação contra a Open Library (live) ou contra o servidor local
# de fixtures, faz um pedido e termina os processos que iniciou.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
MODE=${1:-replay}
case "$MODE" in
    live|replay|missing-author|rate-limit|timeout|bad-json) ;;
    *) echo 'Modos: live replay missing-author rate-limit timeout bad-json'; exit 2 ;;
esac

APP_PORT=${APP_PORT:-18080}
FIXTURE_PORT=${FIXTURE_PORT:-18081}
JAR="$ROOT/target/campus-books-1.0.0.jar"
OUT="$ROOT/evidence/demo"
QUERY="q=software%20engineering&page=1"
[ -f "$JAR" ] || { echo 'Correr ./scripts/verify.sh primeiro.'; exit 1; }

APP_PID=
FIXTURE_PID=
stop() {
    if [ -n "$1" ]; then
        kill "$1" 2>/dev/null || true
        wait "$1" 2>/dev/null || true
    fi
}
cleanup() {
    stop "$APP_PID"
    stop "$FIXTURE_PID"
}
trap cleanup EXIT HUP INT TERM
mkdir -p "$OUT"

if [ "$MODE" = live ]; then
    BASE=https://openlibrary.org
else
    BASE="http://127.0.0.1:$FIXTURE_PORT"
    python3 "$ROOT/scripts/fixture-server.py" --scenario "$MODE" --port "$FIXTURE_PORT" \
        > "$OUT/fixture.log" 2>&1 &
    FIXTURE_PID=$!
fi

java -jar "$JAR" --server.port="$APP_PORT" --books.provider-base-url="$BASE" \
    > "$OUT/app-$MODE.log" 2>&1 &
APP_PID=$!

# A aplicação está pronta quando uma pesquisa inválida devolve 400.
READY=0
for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
    CODE=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$APP_PORT/api/books?q=x" || true)
    if [ "$CODE" = 400 ]; then READY=1; break; fi
    kill -0 "$APP_PID" 2>/dev/null || { cat "$OUT/app-$MODE.log"; exit 1; }
    sleep 1
done
[ "$READY" = 1 ] || { echo 'A aplicação não arrancou'; exit 1; }

printf 'Mode: %s. %s\n' "$MODE" "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
curl -sS --max-time 10 -D "$OUT/headers-$MODE.txt" \
    "http://127.0.0.1:$APP_PORT/api/books?$QUERY" -o "$OUT/response-$MODE.json"
head -1 "$OUT/headers-$MODE.txt"
python3 -m json.tool "$OUT/response-$MODE.json"

if [ "$MODE" != live ]; then
    # Repetir uma pesquisa bem-sucedida deve usar o cache da aplicação.
    case "$MODE" in
        replay|missing-author)
            curl -sS --max-time 10 "http://127.0.0.1:$APP_PORT/api/books?$QUERY" -o /dev/null ;;
    esac
    curl -sS "http://127.0.0.1:$FIXTURE_PORT/__stats"
    printf '\n'
fi
