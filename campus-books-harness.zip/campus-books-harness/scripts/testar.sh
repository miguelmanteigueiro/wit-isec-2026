#!/bin/sh
# Corre o teste HTTP numa das duas versões guardadas no Git, numa cópia temporária.
#   ./scripts/testar.sh antes    código antes da correção, com o teste novo: falha
#   ./scripts/testar.sh depois   código corrigido, com o teste novo: passa
set -eu
VERSAO=${1:-}
case "$VERSAO" in
    antes|depois) ;;
    *) echo 'Uso: ./scripts/testar.sh antes|depois'; exit 2 ;;
esac
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
WORK=$(mktemp -d)
LOG="$ROOT/evidence/demo/testar-$VERSAO.log"

cleanup() {
    git -C "$ROOT" worktree remove --force "$WORK" 2>/dev/null || rm -rf "$WORK"
}
trap cleanup EXIT HUP INT TERM

mkdir -p "$ROOT/evidence/demo"
git -C "$ROOT" worktree add --quiet --detach "$WORK" "$VERSAO"
if [ "$VERSAO" = antes ]; then
    # O teste novo vem da versão depois; o código fica como estava.
    git -C "$WORK" checkout --quiet depois -- src/test
    echo 'Versão antes da correção, com o teste novo'
else
    echo 'Versão depois da correção'
fi

(cd "$WORK" && ./mvnw -B -ntp -Dtest=BooksHttpTest test) > "$LOG" 2>&1 || true

grep -E 'Tests run: [0-9]+, Failures' "$LOG" | tail -1
grep -m1 -E 'expected: <[0-9]+> but was: <[0-9]+>' "$LOG" || true
grep -E 'BUILD (SUCCESS|FAILURE)' "$LOG" || echo "Sem resultado do Maven. Ver $LOG"
