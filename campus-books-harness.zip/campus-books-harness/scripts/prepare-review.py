#!/usr/bin/env python3
"""Prepara um pacote de revisão para uma versão concreta. Não chama nenhum modelo."""
import argparse
from pathlib import Path

from review_support import prepare

parser = argparse.ArgumentParser()
parser.add_argument("--revision", choices=["antes", "atual"], default="atual")
parser.add_argument("--output", required=True)
args = parser.parse_args()

try:
    manifest = prepare(Path(__file__).resolve().parents[1], args.output, args.revision)
except (ValueError, OSError) as error:
    parser.exit(2, f"{error}\n")

print("Review packet prepared:", manifest["packet_id"])
print("No model was called. Start a separate review context.")
