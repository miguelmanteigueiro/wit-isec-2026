import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from review_support import prepare, validate  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]


class ReviewSupportTest(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.packet = Path(self.tmp.name) / "packet"
        self.manifest = prepare(ROOT, self.packet, "atual")
        self.report = {
            "packet_id": self.manifest["packet_id"],
            "review_status": "completed",
            "mode": "fresh_context",
            "models": {"implementer": None, "reviewer": None},
            "context_isolated": True,
            "findings": [],
            "limitations": ["Synthetic unit-test report; no model execution."],
        }

    def tearDown(self):
        self.tmp.cleanup()

    def test_empty_findings_are_allowed(self):
        self.assertEqual([], validate(self.packet, self.report))

    def test_not_run_is_not_completed(self):
        self.report["review_status"] = "not_run"
        self.assertTrue(validate(self.packet, self.report))

    def test_prepared_example_is_not_completed(self):
        self.report["review_status"] = "prepared_example"
        self.assertTrue(validate(self.packet, self.report))

    def test_stale_snapshot_is_rejected(self):
        (self.packet / "source/pom.xml").write_text("changed")
        self.assertTrue(validate(self.packet, self.report))

    def test_wrong_packet_is_rejected(self):
        self.report["packet_id"] = "other"
        self.assertTrue(validate(self.packet, self.report))

    def test_cross_model_requires_distinct_declarations(self):
        self.report.update(mode="cross_model", models={"implementer": "same", "reviewer": "same"})
        self.assertTrue(validate(self.packet, self.report))

    def test_cross_model_declarations_are_only_structural(self):
        self.report.update(mode="cross_model", models={"implementer": "synthetic-A", "reviewer": "synthetic-B"})
        self.assertEqual([], validate(self.packet, self.report))

    def test_author_history_is_excluded(self):
        self.assertFalse((self.packet / "source/plans").exists())
        self.assertFalse((self.packet / "source/reviews").exists())

    def test_path_traversal_finding_is_rejected(self):
        self.report["findings"] = [{
            "file": "../manifest.json", "line": 1, "requirement": "RF05",
            "impact": "example", "reproduction": "example", "evidence_status": "hypothesis",
        }]
        self.assertTrue(validate(self.packet, self.report))

    def finding(self, **overrides):
        base = {
            "file": "src/main/java/pt/isec/campusbooks/BookMapper.java", "line": 1,
            "requirement": "RF05", "impact": "example", "reproduction": "example",
            "evidence_status": "hypothesis",
        }
        return base | overrides

    def test_finding_accepts_source_prefix_and_requirement_text(self):
        self.report["findings"] = [self.finding(
            file="source/src/main/java/pt/isec/campusbooks/BookMapper.java",
            requirement="RF05 / CA03: author_name omitido origina authors vazio")]
        self.assertEqual([], validate(self.packet, self.report))

    def test_finding_rejects_unknown_requirement(self):
        self.report["findings"] = [self.finding(requirement="RF99")]
        self.assertTrue(validate(self.packet, self.report))

    def test_snapshot_is_never_overwritten(self):
        with self.assertRaises(ValueError):
            prepare(ROOT, self.packet)


if __name__ == "__main__":
    unittest.main()
