# Campus Books

Exemplo da palestra *From Spec to Harness* (ISEC, 18/11/2026). Uma API Spring Boot que
adapta a pesquisa da Open Library a um contrato pequeno e próprio.
Java 21, Spring Boot 4.1.1, Maven wrapper. Requer JDK 21, Python 3.9+, git e curl.

## O que é real e o que foi preparado

- **Real:** o código, 24 testes Java, 12 testes Python dos helpers de revisão e a chamada
  à Open Library (captura de 30/10/2026 em `evidence/`). A revisão em
  `evidence/revisao-agente-2026-11-16.json` foi feita por um agente (claude-sonnet-5-5)
  numa sessão nova, só com o pacote da versão `antes`.
- **Preparado para a palestra:** o defeito do RF05 foi introduzido de propósito. O plano
  (`plans/`) e a revisão (`reviews/`) foram escritos à mão. Não há pipeline remota instalada.

## Começar

```sh
./scripts/demo-harness.sh         # a demo: um engenheiro e o agente no percurso do harness (Enter para avançar)
./scripts/verify.sh               # contexto, testes Python e Maven verify (cria o JAR)
./scripts/demo.sh replay          # aplicação contra a captura guardada
./scripts/demo.sh rate-limit      # fornecedor devolve 429; a API responde 503
./scripts/testar.sh antes         # teste novo do RF05 no código antes da correção: falha
./scripts/testar.sh depois        # o mesmo teste no código corrigido: passa
./scripts/reproduce.sh            # sequência completa, com a suite inteira
```

A primeira execução do Maven precisa de rede. `./scripts/demo.sh live` consulta a API
pública e só deve ser usado quando se quer mesmo uma chamada real. Os outros modos e os
testes usam apenas 127.0.0.1 (portas 18080 e 18081, ou `APP_PORT` e `FIXTURE_PORT`).

## Histórico

```sh
git log --oneline --decorate
git diff antes depois --stat     # o que mudou com o RF05
git diff antes depois            # código, testes e regra nova na skill
```

| Tag | Estado |
|---|---|
| `antes` | Versão antes da correção. O RF05 está na spec mas não no código. 21 testes verdes. |
| `depois` | Correção do `BookMapper`, 3 testes novos e uma regra nova na skill. 24 testes verdes. |
| `main` | `depois` mais a evidência e a review preparada. |

## Onde está cada coisa

- `specs/book-search.md`: spec por tópicos, com IDs (AS, RF, RNF, RS, CA).
- `AGENTS.md`: ponto de entrada do contexto para agentes.
- `.agents/skills/`: procedimentos reutilizáveis (integrar uma API, rever uma alteração).
- `docs/`: integração, arquitetura, testes, rastreabilidade e protocolo de revisão.
- `prompts/`: pedidos para implementar e para rever.
- `scripts/`: verificação, demo, reprodução e helpers de revisão.
- `evidence/`: logs datados e captura real da Open Library.

## Limites

Projeto académico, uma instância, baixo volume. Cache e limite de pedidos são por instância.
Não há frontend, contas, base de dados, testes de carga nem deploy. Antes de qualquer uso
regular, rever as condições atuais da Open Library. Dados: Open Library / Internet Archive.
