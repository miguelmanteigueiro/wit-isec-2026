# Integração com Open Library

Destino normal: `https://openlibrary.org/search.json`. O URL não vem do pedido do utilizador.
Campos pedidos: key, title, author_name, first_publish_year. O domínio usa DTOs próprios.
`author_name` e `first_publish_year` são opcionais na nossa política de adaptação.

400 local: validação. 502: payload/estado remoto inválido. 503: quota local, 429 remoto ou
interrupção. 504: timeout do HttpClient. Sem retries automáticos.

Connect timeout 1 s. Request timeout 3 s. Cache de sucesso 60 s/100 entradas.
Guard local de 1100 ms entre tentativas. Limites são decisões didáticas, não um SLA nem
uma garantia de quota agregada. Configuração HTTP 127.0.0.1 é para o fixture server.

API real: https://openlibrary.org/dev/docs/api/search
Política: https://openlibrary.org/developers/api
Confirmado em 30/10/2026. Revalidar antes de utilização regular.
