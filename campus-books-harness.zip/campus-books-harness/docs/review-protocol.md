# Protocolo de revisão crítica e contexto separado

Proposta didática para a palestra (12/11/2026).

## 1. Três escolhas diferentes
- **Contexto:** uma sessão nova, ou um subagente configurado sem o histórico do autor.
- **Modelo:** o mesmo modelo ou outro. Modelos diferentes podem partilhar pontos cegos.
- **Objetivo:** procurar contraexemplos à spec, não defender a implementação.
O checkpoint usa contexto separado. A diversidade de modelo é opcional. A ferramenta
concreta determina isolamento e permissões; este repositório não instala uma sandbox.

## 2. Um loop principal por defeito
Planeamento, implementação e testes podem ser fases do mesmo agente com skills e
contexto progressivo. Separar apenas se houver uma fronteira útil: trabalho independente
em paralelo, isolamento real de contexto/acesso ou verificação crítica. O custo pode
incluir reconstrução de contexto, coordenação e perda de detalhes. Um subagente não tem
necessariamente de ler todo o repositório. Medir qualidade, tempo total e falsos positivos;
não tratar menos agentes como uma lei universal.

## 3. Preparar uma versão concreta
```sh
python3 scripts/prepare-review.py --revision antes --output .review/antes
python3 scripts/prepare-review.py --revision atual --output .review/atual
```
Os destinos devem ser novos. O helper não chama um modelo nem executa scripts copiados.
`antes` usa a tag Git com o mesmo nome (RF05 por implementar). `atual` copia os
ficheiros atuais e junta o diff desde `antes`.

Entregar **apenas o pacote** a uma sessão separada, mais prompts/adversarial-review.md.
Inclui spec, decisões aprovadas, código, testes, diff e evidência datada. Exclui plano,
review preparada e conversa do implementador. Não esconder decisões aprovadas essenciais.
Uma pergunta pertinente do revisor é melhor do que uma conclusão baseada em contexto em falta.

O manifest associa conteúdo a hashes/packet_id; não é uma assinatura. Os logs históricos
não certificam a versão atual. O log V3, quando existe, está identificado à parte.
As permissões do cliente devem limitar a revisão à leitura. Para reproduzir, copiar source/
para uma área descartável autorizada e executar Maven apenas depois de rever scripts e
confirmar ambiente/dependências. A suite usa localhost; o primeiro build pode baixar Maven
ou dependências. Não dar acesso de escrita ao checkout do autor ou a credenciais.

## 4. Relatório e evidência
Usar report-template.json. Campos: packet_id, review_status, mode, models,
context_isolated, findings, limitations. Estados:
- `not_run`: nenhum trabalho de revisão declarado.
- `prepared_example`: material pedagógico, NÃO é uma revisão real executada.
- `completed`: declaração feita por quem efetivamente realizou a revisão.
Modos: `fresh_context` ou `cross_model` (IDs declarados distintos no segundo).
Cada finding tem file, line, requirement, impact, reproduction e evidence_status.
Distinguir hipótese, reprodução efetiva e não reprodução; nenhum número mínimo de findings.

```sh
python3 scripts/validate-review.py --packet .review/atual --report caminho/relatorio.json
```
O validador rejeita snapshots alterados, packet_id errado, estados não concluídos e
findings sem localização/requisito/evidência mínima. Verifica **estrutura e vínculo**,
não autentica modelos/isolamento, não comprova execução e não deteta todos os defeitos.
Mesmo `completed` e zero findings não representam aprovação humana ou um merge autorizado.
O exemplo reviews/adversarial-review.prepared.json permanece prepared_example e deve ser
rejeitado como revisão concluída. Os testes usam declarações sintéticas, não agentes.

## 5. Correção, desacordo e paragem
A pessoa classifica a observação: defeito, risco, falso positivo ou contexto em falta.
Aceitar apenas com base na spec e evidência. O implementador corrige o que foi aceite e
repete os checks. Uma mudança de conteúdo exige pacote novo; rever o novo diff e, pelo
menos, as áreas afetadas e regressões. Não aplicar o relatório antigo a código diferente.
O orçamento sugerido é duas tentativas de reparação; depois escalar à pessoa. Não fazer
votação de modelos, ampliar permissões ou acumular regras por cada falso positivo.

## 6. Avaliação antes de institucionalizar
Usar evals/agent-strategies.md para comparar estratégias com os mesmos casos. Há um defeito
conhecido (RF05) e uma versão corrigida para observar falsos positivos. Não há medição real
de taxa de deteção, custo, latência ou superioridade de modelo nesta entrega.

## Fontes
- Anthropic, Diane Sarkis, 22/10/2026: https://claude.com/resources/articles/building-agents-when-to-fold-subagents-into-your-main-agent-loop
- OpenAI, CriticGPT (crítica também pode errar): https://openai.com/index/finding-gpt4s-mistakes-with-gpt-4/
Consultadas em 12/11/2026. O protocolo concreto acima é uma proposta para esta palestra.
