# Arquitetura

BooksController expõe o contrato local. BookSearchService valida, normaliza e mantém o
cache local. OpenLibraryClient controla o destino e a chamada HTTP. BookMapper projeta
os metadados num Book. ApiErrors traduz erros sem devolver o payload remoto.

A configuração permite apenas HTTPS openlibrary.org ou HTTP 127.0.0.1 para testes/replay.
Apenas OpenLibraryClient tem imports java.net no código de produção.
`scripts/check-context.py` confirma esta regra simples de imports, não uma análise completa
de fluxos de dados. É possível contorná-la por outros mecanismos; não é uma sandbox.

A sincronização local e o cache em memória simplificam o exemplo e não suportam uma
promessa de latência/concurrency em produção. Não há base de dados nem disponibilidade
real de livros para empréstimo.
