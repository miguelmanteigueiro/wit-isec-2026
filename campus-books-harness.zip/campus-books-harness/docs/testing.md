# Verificação e evidência

`./scripts/verify.sh` valida os ficheiros de contexto e executa `./mvnw -B -ntp verify`.
JDK 21 e Python 3.9+. O wrapper pode descarregar Maven e dependências na primeira execução.
A suite não chama a Open Library. HTTP de teste usa apenas 127.0.0.1 e portas aleatórias.

- BookMapperTest: projeção e tipos de metadados.
- BookSearchServiceTest: normalização, validação, chave, TTL e limite do cache.
- OpenLibraryClientTest: contrato do pedido, falhas, timeout e orçamento local.
- BooksHttpTest: endpoint Spring Boot completo contra fornecedor local controlado.

Fixtures `complete`, `missing-author` e `empty` são sintéticas e identificadas como tal.
A captura `evidence/openlibrary-live.json` é real. Não a confundir com resultados atuais.
A sua data e proveniência estão em `evidence/live-capture.md`.

As tags Git `antes` e `depois` guardam o código antes e depois da correção do RF05.
`./scripts/testar.sh antes|depois` corre só `BooksHttpTest` numa cópia temporária;
em `antes`, usa os testes de `depois` para mostrar o teste novo a falhar.
`./scripts/reproduce.sh` repete a sequência com a suite inteira.
`./scripts/demo.sh live` testa a ligação real, separadamente e por decisão do apresentador.
Não chamar a API pública na pipeline nem correr live em loops de reparação de agentes.

## Helpers de revisão
`verify.sh` corre também 12 testes Python dos helpers de revisão (offline, sem modelos).
Confirmam que `not_run`/`prepared_example` não passam por revisão concluída e que snapshots
alterados, IDs errados e caminhos fora do snapshot são rejeitados.
