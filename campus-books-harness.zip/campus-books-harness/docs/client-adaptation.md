# Adaptação do cliente e controlos

As pastas `.agents/skills` ilustram o formato Agent Skills. A descoberta depende do cliente.
Invocar e confirmar explicitamente a leitura quando a ferramenta não as descobre neste caminho.
AGENTS.md pode precisar de adaptação por cliente. Não instalar imports ou duplicar regras sem
confirmar a precedência e o contexto carregado na versão usada.

`.claude/settings.example.json` é um exemplo específico de Claude Code, NÃO ativo por defeito.
Rever e testar antes de copiar para settings.json. PostToolUse corre depois de uma edição:
não desfaz a edição nem impede um merge. As regras Read não impedem todos os acessos indiretos.
O exemplo não ativa sandbox, não configura rede e não protege o servidor Git.

No ambiente real: configurar menor privilégio, restrição de egress, credenciais adequadas,
aprovações de operações sensíveis e branch protection com checks obrigatórios no servidor.
Não permitir que o agente altere as próprias políticas de controlo.

Referências, consultadas em 30/10/2026:
https://agentskills.io/specification
https://code.claude.com/docs/en/memory
https://code.claude.com/docs/en/hooks
https://code.claude.com/docs/en/permissions

## Contexto e revisão (12/11/2026)
O cliente pode implementar a revisão com uma sessão nova ou um subagente de contexto
separado. Confirmar se herda histórico/permissões; o nome “revisor” não prova isolamento.
Um modelo diferente é opcional e não implica independência estatística. Configurar
acessos mínimos fora dos prompts; este pacote não ativa perfis de revisão nem chama modelos.
Ver docs/review-protocol.md.
