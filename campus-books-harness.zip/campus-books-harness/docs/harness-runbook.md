# Execução do harness na palestra

1. Rever scripts, criar checkout sem credenciais e confirmar controlos reais do cliente.
2. Ler AGENTS.md e spec; carregar documentação/skills relevantes progressivamente.
3. Validar assumptions e âmbito. Usar prompts/implement-change.md no loop principal.
4. Planear, implementar e testar no mesmo loop. Não criar um agente por papel.
5. Executar scripts/verify.sh e conservar resultado; não aceitar apenas uma declaração.
6. Preparar um pacote e aplicar docs/review-protocol.md num contexto separado. Outro
   modelo é opcional. Sem conversa do autor, mas com decisões aprovadas suficientes.
7. Procurar contraexemplos, sem quota de findings. Reproduzir em cópia descartável autorizada.
8. Uma pessoa decide o que corrigir; repetir checks e atualizar pacote quando o código muda.
   Após duas tentativas sem evidência suficiente, parar/escalar, não aumentar permissões.
9. A pessoa aceita a alteração com base em critérios, evidência e limites, não por maioria de modelos.

Na palestra: mostrar o teste do RF05 a falhar na versão `antes` e a passar na `depois`,
e explicar que `prepare-review.py` gera um pacote `not_run`. O código e os testes são reais;
o plano e a review em `plans/` e `reviews/` foram preparados à mão.
