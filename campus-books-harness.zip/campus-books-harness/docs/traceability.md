# Rastreabilidade e limites da evidência

| Critério | Evidência do exemplo |
|---|---|
| CA01 | OpenLibraryClientTest.forwardsPageAndEncodesQuery |
| CA02 | BooksHttpTest.invalidQueryReturns400WithoutProviderCall e BookSearchServiceTest.rejectsInvalidInputBeforeCallingProvider |
| CA03 | BooksHttpTest.missingAuthorReturnsEmptyArray e BookMapperTest.normalizesNullAuthors |
| CA04 | OpenLibraryClientTest.emptySearchIsSuccessful e BooksHttpTest.providerOutageDoesNotLookLikeEmptyResults |
| CA05 | OpenLibraryClientTest: providerRateLimitBecomes503, providerFailureBecomes502, invalidJsonBecomes502, timeoutBecomes504 |
| CA06 | BookSearchServiceTest.normalizesAndCachesSuccessfulSearch e pageIsPartOfCacheKey |
| CA07 | BookSearchServiceTest.expiresCacheAtSixtySeconds e boundsCacheSize |
| CA08 | OpenLibraryClientTest.limitsAttemptsWithoutWaiting |
| CA09 | OpenLibraryClientTest.rejectsArbitraryProviderHost e scripts/check-context.py |
| CA10 | Revisão da configuração de testes e evidência live separada |

A tabela indica exemplos de evidência. Não prova cobertura exaustiva. Por exemplo, o teste
HTTP usa um fornecedor local, a quota não foi testada entre réplicas e o OpenAPI é uma
referência de contrato, não um validador completo de cada payload no pipeline.
Não foram realizados testes de carga ou avaliação completa de segurança.
