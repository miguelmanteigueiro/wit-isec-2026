---
name: review-change
description: Rever criticamente um diff contra a spec e os checks, procurando contraexemplos sem editar a implementação.
---

1. Ler `docs/review-protocol.md` e o pacote da versão a rever.
2. Ler spec, decisões aprovadas, diff, código e testes relevantes e evidência dos checks.
   A narrativa do autor não é prova. Pedir as decisões que faltarem.
3. Procurar contraexemplos: opcionais/null/tipos errados, erro versus vazio, cache/página,
   limites e rede. Zero findings é um resultado válido.
4. Para cada finding: ficheiro/linha, requisito, impacto, reprodução ou teste proposto e
   estado da evidência (hipótese, reproduzido, não reproduzido).
5. Não editar código. Reproduzir só numa cópia descartável, sem chamar a API pública.
6. Se o código mudar, o pacote muda: repetir checks e revisão nas áreas afetadas.
7. Uma pessoa decide. Desacordos resolvem-se com evidência, não com votação de modelos.
