# Plano preparado: Campus Books

Plano escrito à mão para ilustrar o papel de planeamento.

1. Validar assumptions e decisões da spec com uma pessoa.
2. Rever contrato Open Library e limites. Fixar projeção, paginação e erros.
3. Criar adapter e contrato próprio sem acoplar o controller ao payload externo.
4. Implementar normalização, cache e orçamento local de pedidos.
5. Cobrir sucesso, campos omitidos/null, página, 429, 5xx, JSON inválido e timeout.
6. Executar checks offline e rever o diff contra os IDs da spec.
7. Por decisão do apresentador, realizar um smoke live de baixo volume e guardar evidência.

Ponto de decisão: contas/listas pessoais ficam fora de âmbito.
A versão inicial (tag `antes`) omite o RF05 de propósito, apesar de o plano o prever.
