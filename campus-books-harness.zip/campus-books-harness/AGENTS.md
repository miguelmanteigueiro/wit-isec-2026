# Campus Books: contexto de entrada

Java 21 e Spring Boot 4.1.1. API académica que adapta a pesquisa da Open Library.

## Antes de alterar
- Ler `specs/book-search.md` para âmbito, assumptions e critérios.
- Ler `docs/integration.md` ao tocar no adapter HTTP ou nos seus DTOs.
- Ler `docs/testing.md` antes de alterar testes ou comandos.
- Carregar só o contexto necessário para a tarefa.

## Fluxo
- Planear, implementar e testar no mesmo loop, usando as skills de `.agents/skills/`.
- Só separar trabalho num subagente com uma razão concreta: trabalho independente,
  isolamento de contexto/acesso ou uma revisão crítica.
- Revisão: seguir `docs/review-protocol.md`.

## Comandos
- Verificar tudo: `./scripts/verify.sh`
- Teste HTTP isolado: `./mvnw -B -ntp -Dtest=BooksHttpTest test`
- Replay local: `./scripts/demo.sh replay`
- Chamada real à Open Library, só a pedido: `./scripts/demo.sh live`

## Regras não óbvias
- Rede de produção só no `OpenLibraryClient`. Nunca aceitar URLs vindos do utilizador.
- Os testes não chamam a API pública. Usar fixtures e localhost.
- Uma falha remota nunca se transforma numa pesquisa vazia bem-sucedida.
- Não remover testes nem alargar limites para obter verde.

## Ao terminar
- Relacionar os critérios da spec com os testes e rever o diff.
- Reportar comandos, resultados e o que ficou por verificar.
- Não fazer commit, push, release ou deploy sem pedido explícito. Uma pessoa aceita.
